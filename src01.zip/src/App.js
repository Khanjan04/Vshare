import React from 'react';
import Title from './comps/Title';
import UploadForm from './comps/UploadForm';
import ImageGrid from './comps/ImageGrid';
import Qlist from './QnA/Qlist';

function App() {
  return (
    <div className="App">
      
      
      <UploadForm/>
      <ImageGrid/>
      
     <div>
     <br/>
     </div>
     <div>
     <br/>
     </div>
     <div>
     <br/>
     </div>
     <div>
     <br/>
     </div>
     
      <Qlist/>
    
      
    
    </div>
  );
}

export default App;
